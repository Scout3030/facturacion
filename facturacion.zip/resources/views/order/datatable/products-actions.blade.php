<div class="d-flex">
    <button class="btn btn-rounded btn-warning add-to-cart" data-id="{{$id}}" data-product="{{$id}}">{{__("Añadir")}}</button>
</div>
