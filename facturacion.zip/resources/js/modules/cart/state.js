export default {
    products: [],
}
