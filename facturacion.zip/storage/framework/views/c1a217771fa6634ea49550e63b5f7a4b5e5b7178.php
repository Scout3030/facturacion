<div class="scrollbar-sidebar">
    <div class="app-sidebar__inner">
        <ul class="vertical-nav-menu">
            <li class="app-sidebar__heading">Dashboards</li>
            <li>
                <a href="<?php echo e(route('home.index')); ?>">
                    <i class="metismenu-icon pe-7s-rocket"></i>
                    Dashboard
                </a>
            </li>
            <li class="app-sidebar__heading">Ventas</li>
            <li>
                <a href="<?php echo e(route('sell.index')); ?>" <?php if(Request::url() == route('sell.index')): ?> class="mm-active" <?php endif; ?>>
                    <i class="metismenu-icon pe-7s-play"></i>
                    En proceso
                    <i class="metismenu-state-icon caret-left"></i>
                </a>
            </li>







            <li class="app-sidebar__heading">Clientes</li>
            <li>
                <a href="<?php echo e(route('clients.index')); ?>" <?php if(Request::url() == route('clients.index')): ?> class="mm-active" <?php endif; ?>>
                    <i class="metismenu-icon pe-7s-attention"></i>
                    Administrar
                    <i class="metismenu-state-icon caret-left"></i>
                </a>
            </li>
            <li class="app-sidebar__heading">PRO Version</li>
            <li>
                <a href="https://demo.dashboardpack.com/architectui-html-pro/" target="_blank">
                    <i class="metismenu-icon pe-7s-graph2">
                    </i>
                    Upgrade to PRO
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\facturacion\resources\views/admin/shared/sidebar.blade.php ENDPATH**/ ?>