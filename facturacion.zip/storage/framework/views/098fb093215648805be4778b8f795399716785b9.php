<div class="d-flex">
    <a href="<?php echo e(route('categories.edit', ['category' => $id])); ?>" class="btn btn-rounded btn-warning"><?php echo e(__("Editar")); ?></a>
    <form action="<?php echo e(route('categories.delete', ['category' => $id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button class="btn btn-rounded btn-danger" type="submit"><?php echo e(__('Eliminar')); ?></button>
    </form>
</div>
<?php /**PATH C:\laragon\www\facturacion\resources\views/category/datatable/actions.blade.php ENDPATH**/ ?>