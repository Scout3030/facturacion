<div class="d-flex">
    <a href="<?php echo e(route('products.edit', ['product' => $id])); ?>" class="btn btn-rounded btn-warning"><?php echo e(__("Editar")); ?></a>
    <form action="<?php echo e(route('products.delete', ['product' => $id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button class="btn btn-rounded btn-danger" type="submit"><?php echo e(__('Eliminar')); ?></button>
    </form>
</div>
<?php /**PATH C:\laragon\www\facturacion\resources\views/product/datatable/actions.blade.php ENDPATH**/ ?>