<div class="d-flex">
    <button class="btn btn-rounded btn-warning add-to-cart" data-id="<?php echo e($id); ?>" data-product="<?php echo e($id); ?>"><?php echo e(__("Añadir")); ?></button>
</div>
<?php /**PATH C:\laragon\www\facturacion\resources\views/order/datatable/products-actions.blade.php ENDPATH**/ ?>