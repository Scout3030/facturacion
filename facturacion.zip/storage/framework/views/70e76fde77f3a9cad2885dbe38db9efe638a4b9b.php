<form action="<?php echo e(route('clients.delete', ['client' => $id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    <button class="btn btn-rounded btn-danger" type="submit"><?php echo e(__('Eliminar')); ?></button>
</form>
<?php /**PATH C:\laragon\www\facturacion\resources\views/client/datatable/actions.blade.php ENDPATH**/ ?>