<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/vector-map/jqvmap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jvectormap/jquery-jvectormap-2.0.2.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/charts/chartist-bundle/chartist.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/charts/morris-bundle/morris.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/charts/c3charts/c3.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/flag-icon-css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/daterangepicker/daterangepicker.css')); ?>" type="text/css" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <!-- ============================================================== -->
        <!-- working capital  -->
        <!-- ============================================================== -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div id="sales-chart" style="height: 250px;"></div>
                    <div class="text-center m-t-10">
                            <span class="legend-item mr-3">
                                <span class="fa-xs text-secondary mr-1 legend-tile">
                                    <i class="fa fa-fw fa-square-full"></i>
                                </span>
                                <span class="legend-text">Ventas por día</span>
                            </span>
                        <p></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end working capital  -->
        <!-- ============================================================== -->
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>














    <!-- morris js -->
    <script src="<?php echo e(asset('assets/vendor/charts/morris-bundle/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/charts/morris-bundle/morris.js')); ?>"></script>





















<script>
    new Morris.Area({
        // ID of the element in which to draw the chart.
        element: 'sales-chart',
        // Chart data records -- each entry in this array corresponds to a point on
        // the chart.
        data: [
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            { day: '<?php echo e($key); ?>', value: <?php echo e($order->sum('total')); ?> },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        // The name of the data record attribute that contains x-values.
        xkey: 'day',
        // A list of names of data record attributes that contain y-values.
        ykeys: ['value'],
        // Labels for the ykeys -- will be displayed when you hover over the
        // chart.
        labels: ['Total'],
        xLabels: 'day',
        // postUnits: 'S/',
        preUnits: 'S/',
        // behaveLikeLine : true
        // yLabelFormat: function (y) { return 'S/'+y; },
        // xLabelFormat: function (x) { return x; }
        xLabelAngle: 30
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\facturacion\resources\views/home.blade.php ENDPATH**/ ?>