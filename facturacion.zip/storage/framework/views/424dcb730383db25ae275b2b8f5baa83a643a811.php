<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header"><?php echo e(__('Registrar nueva orden')); ?></h5>
                <div class="card-body">
                    <form method="POST" action="<?php echo e($order->id ? route('orders.update', ['order' => $order->id]) : route('orders.store')); ?>">
                        <?php if($order->id): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="input-select"><?php echo e(__("Cliente")); ?></label>
                            <select class="form-control" id="input-select" name="client_id" <?php echo e($order->id ? 'readonly' : ''); ?>>
                                <?php if(!$order->id): ?>
                                    <option value=""><?php echo e(__("Seleccione cliente")); ?></option>
                                    <?php $__currentLoopData = \App\Client::pluck('title', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e((int) old('client_id') === $id || $order->client_id === $id ? 'selected' : ''); ?> value="<?php echo e($id); ?>">
                                            <?php echo e($title); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <option selected value="">
                                        <?php echo e($order->client->title); ?>

                                    </option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="form-row" id="cart"></div>

                        <div class="form-row">
                            <input type="hidden" name="cart" value="">
                            <label><?php echo e(__('Total')); ?> (S/)</label>
                            <input class="form-control totalCart" value="0" readonly>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <button class="btn btn-primary mt-3" type="submit"><?php echo e($btnText); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12">
            <?php echo $__env->make('order.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            let cart = <?php echo $orderLines; ?>;
            if (cart.length){
                manageCart(cart)
            }
            let cartNode = $("#cart");
            $('#products-table').on('click', '.add-to-cart', function () {
                $(this).attr("disabled", true)
                let productId = $(this).data('id')
                let productIn = cart.find(x => x.id === productId);
                if ( !productIn )
                {
                    jQuery.ajax({
                        url: `<?php echo e(route('products.show-product')); ?>`,
                        type: 'POST',
                        headers: {
                            'x-csrf-token': $("meta[name=csrf-token]").attr('content')
                        },
                        data: {
                            productId: productId
                        },
                        success: (res) => {
                            console.log(res)
                            cart.push(res)
                            manageCart(cart)
                        }
                    })
                }
            })

            cartNode.on('click', '.deleteProduct', function(e){
                e.preventDefault()
                let productId = $(this).data('id')
                // console.log($('[data-product='+productId+']'))
                // $('[data-product='+productId+']')[0].disabled = false
                let index = cart.findIndex(x => x.id === productId)
                cart.splice(index,1)
                manageCart(cart)
            })

            cartNode.on('change', '.productQty', function(){
                let qty = $(this)[0].value
                let productId = $(this).data('id')
                let index = cart.findIndex(x => x.id === productId)
                cart[index].qty = Number(qty);
                manageCart(cart)
                // let qty = $(this)[0].value
                // let priceNode = $(this).parent().next();
                // let subtotalNode = $(this).parent().next().next();
                // let price = priceNode.children()[1].value
                // let subtotal = qty * price
                // subtotalNode.children()[1].value = subtotal
                // console.log('subtotal', subtotal)
            })

            cartNode.on('change', '.productPrice', function(){
                let price = $(this)[0].value
                let productId = $(this).data('id')
                let index = cart.findIndex(x => x.id === productId)
                cart[index].price = Number(price);
                manageCart(cart)
            })

            function manageCart(cart){
                cartHtml(cart)
                serializeCart(cart)
                calculateTotal(cart)
            }

            function calculateTotal(cart){
                let total = cart.reduce(function(accumulator, product) {
                    return parseFloat(accumulator) + (parseFloat(product.price) * parseInt(product.qty))
                }, 0)
                $('.totalCart').val(total)
            }

            function serializeCart(cart)
            {
                $('input[name=cart]').val(JSON.stringify(cart))
            }

            function cartHtml(cart)
            {
                let htmlCart = $('#cart')
                let html = "";
                htmlCart.empty()
                cart.forEach(product => {
                    html +=
                        `<div class="col-xl-2 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label><?php echo e(__('Código')); ?></label>
                            <input type="text" class="form-control" value="${product.code}" readonly required>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label><?php echo e(__('Producto')); ?></label>
                            <input type="text" class="form-control" value="${product.name}" readonly>
                        </div>
                        <div class="col-xl-2 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label><?php echo e(__('Cantidad')); ?></label>
                            <input type="number" class="form-control productQty" data-id="${product.id}" min="1" max="${product.stock}" required="" value="${product.qty}">
                        </div>
                        <div class="col-xl-2 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label><?php echo e(__('Precio')); ?></label>
                            <input type="number" class="form-control productPrice" min="1" step="0.01" data-id="${product.id}" value="${product.price}" required="">
                        </div>
                        <div class="col-xl-2 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label ><?php echo e(__('Subtotal')); ?></label>
                            <input type="text" class="form-control" value="${product.price * product.qty}" required="" readonly>
                        </div>
                        <div class="col-xl-1 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <button class="btn btn-primary mt-4 deleteProduct text-white" data-id="${product.id}">x</button>
                        </div>
                        `
                });

                htmlCart.append(html)
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\facturacion\resources\views/order/form.blade.php ENDPATH**/ ?>