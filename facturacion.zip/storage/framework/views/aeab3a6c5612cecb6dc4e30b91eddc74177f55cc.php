<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="p-3 mb-2 bg-success text-white"><?php echo e(session('message')); ?></div>
</div>
<?php /**PATH C:\laragon\www\facturacion\resources\views/shared/alert.blade.php ENDPATH**/ ?>