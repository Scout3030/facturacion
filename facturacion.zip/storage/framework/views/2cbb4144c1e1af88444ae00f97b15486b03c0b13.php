<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header"><?php echo e(__('Registrar nuevo categoría')); ?></h5>
            <div class="card-body">
                <form method="POST" action="<?php echo e($category->id ? route('categories.update', ['category' => $category->id]) : route('categories.store')); ?>">
                    <?php if($category->id): ?>
                        <?php echo method_field('put'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title"><?php echo e(__('Nombre de categoría')); ?></label>
                        <input id="title" name="name" type="text" class="form-control" value="<?php echo e($category->id ? $category->name : old('name')); ?>">
                    </div>

                    <button class="btn btn-primary mt-3" type="submit"><?php echo e($btnText); ?></button>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#sunat-data').click( function () {
                $('#loader').addClass('d-block')
                jQuery.ajax({
                    url: `<?php echo e(route('clients.sunat')); ?>`,
                    type: 'POST',
                    headers: {
                        'x-csrf-token': $("meta[name=csrf-token]").attr('content')
                    },
                    data: {
                        document : $('#document_number').val()
                    },
                    success: (res) => {
                        $('#loader').removeClass('d-block')
                        console.log(res)
                        $('#title').val(res.razon_social)
                    }
                })
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\facturacion\resources\views/category/form.blade.php ENDPATH**/ ?>