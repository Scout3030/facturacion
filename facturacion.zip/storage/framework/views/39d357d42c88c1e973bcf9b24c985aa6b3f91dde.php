<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header"><?php echo e(__('Registrar nuevo producto')); ?></h5>
            <div class="card-body">
                <form method="POST" action="<?php echo e($product->id ? route('products.update', ['product' => $product->id]) : route('products.store')); ?>">
                    <?php if($product->id): ?>
                        <?php echo method_field('put'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="input-select"><?php echo e(__("Categoría")); ?></label>
                        <select class="form-control" id="category-select" name="category_id">
                            <?php if(!$product->id): ?><option value=""><?php echo e(__("Seleccione categoría")); ?></option><?php endif; ?>
                            <?php $__currentLoopData = \App\Category::pluck('name', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e((int) old('category_id') === $id || $product->category_id === $id ? 'selected' : ''); ?> value="<?php echo e($id); ?>">
                                    <?php echo e($name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="title"><?php echo e(__('Código de producto')); ?></label>
                        <div class="input-group input-group-sm">
                            <input name="code" type="text" class="form-control" value="<?php echo e($product->id ? $product->code : old('code')); ?>">
                            <div class="input-group-append">
                                <button id="generateProductCode" type="button" class="btn btn-primary">Generar automaticamente</button>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="title"><?php echo e(__('Nombre de producto')); ?></label>
                        <input id="title" name="name" type="text" class="form-control" value="<?php echo e($product->id ? $product->name : old('name')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="title"><?php echo e(__('Costo')); ?></label>
                        <input id="title" name="cost" type="number" step="0.1" class="form-control" value="<?php echo e($product->id ? $product->cost : old('cost')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="title"><?php echo e(__('Precio')); ?></label>
                        <input id="title" name="price" type="number" step="0.01" class="form-control" value="<?php echo e($product->id ? $product->price : old('price')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="title"><?php echo e(__('Stock')); ?></label>
                        <input id="title" name="stock" type="number" class="form-control" value="<?php echo e($product->id ? $product->stock : old('stock')); ?>">
                    </div>
                    <button class="btn btn-primary mt-3" type="submit"><?php echo e($btnText); ?></button>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            let categoryId
            $('#category-select').change(function(){
                categoryId = this.selectedOptions[0].value
            })
            $('#generateProductCode').click( function () {
                $('#loader').addClass('d-block')
                jQuery.ajax({
                    url: `<?php echo e(route('products.generate-product-code')); ?>`,
                    type: 'POST',
                    headers: {
                        'x-csrf-token': $("meta[name=csrf-token]").attr('content')
                    },
                    data: {
                        categoryId : categoryId
                    },
                    success: (res) => {
                        $('input[name="code"]').val(res)
                        console.log(res)
                    }
                })
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\facturacion\resources\views/product/form.blade.php ENDPATH**/ ?>